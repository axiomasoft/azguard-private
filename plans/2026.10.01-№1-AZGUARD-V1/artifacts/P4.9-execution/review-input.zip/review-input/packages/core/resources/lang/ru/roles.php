<?php

declare(strict_types=1);

return [
    'superadmin' => 'Суперадмин',
];
